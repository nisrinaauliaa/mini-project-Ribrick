<footer class="footer ">
    <div class="container ">
        <p class="mt-5 mb-3 text-muted text-center">&copy; RIBRICK 2022</p>
    </div>
</footer><?php /**PATH C:\Users\NISRINA AULIA RAHMA\mini-project\resources\views/layouts/footer.blade.php ENDPATH**/ ?>