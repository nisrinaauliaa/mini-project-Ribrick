
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row mb-4">
        <div class="col-12">
            <h5 class="mt-5 mb-4">Todo List</h5>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <table class="table table-hover ">
                <thead>
                    <tr>
                        <th scope="col ">Title</th>
                        <th scope="col ">Description</th>
                        <th scope="col ">Created At</th>
                        <th scope="col ">Status</th>
                        <th scope="col ">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($todo->title); ?></td>
                        <td><?php echo e($todo->description); ?></td>
                        <td><?php echo e($todo->created_at); ?></td>
                        <td>
                            <?php if($todo->done_at): ?>
                            <span class="badge badge-info text-white ">Done</span>
                            <?php else: ?>
                            <span class="badge badge-danger text-white ">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group " role="group " aria-label="Basic example ">
                                <?php if(!$todo->done_at): ?>
                                <a href="<?php echo e(route('done', $todo->id)); ?>" class="btn btn-primary text-white ">
                                    <i class='bx bx-check'></i>
                                </a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('edit', $todo->id)); ?>" class="btn btn-info text-white ">
                                    <i class='bx bx-pencil'></i>
                                </a>
                                <form action="<?php echo e(route('destroy', $todo->id)); ?>" method="POST" onSubmit="return confirm('Do you really want to delete to-do?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger text-white ">
                                        <i class='bx bx-trash'></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">Tidak ada data</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="card-header"><a href="<?php echo e(route('exporttodo')); ?>" class="btn btn-success">Export</a></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\NISRINA AULIA RAHMA\mini-project\resources\views/index.blade.php ENDPATH**/ ?>